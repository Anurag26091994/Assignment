package com.yash.JUnit_Testing_Example.Intermediatefourthex;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.yash.JUnit_Testing_Example.Intermediatefourthex.CarShopApp;

public class NoOfCarSoldTest {
	CarShopApp capp=new CarShopApp();
	
	@Test
	public void test_ShouldReturn_Book_AsOutput() 
	{
		 
		int count=capp.NoofCarSold();
		assertEquals(count, 7);
		
	}

}
