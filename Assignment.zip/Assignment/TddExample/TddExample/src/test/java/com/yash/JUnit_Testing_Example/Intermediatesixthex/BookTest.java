package com.yash.JUnit_Testing_Example.Intermediatesixthex;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.yash.JUnit_Testing_Example.Intermediatefifthex.Student;
import com.yash.JUnit_Testing_Example.Intermediatesixthex.Test1;

public class BookTest {
Test1 t=new Test1();

@Test
public void test_ShouldReturn_Book_AsOutput() 
{
	 
	int count=t.bookcount("balaguruswamy");
	assertEquals(count, 3);
	
}

}
