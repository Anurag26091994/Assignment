package com.yash.JUnit_Testing_Example.stringassignmentfour;

public class CategoryMain {
public static void main(String[] args) {
	Category c =new Category();
	
	String cdetail=c.showCategoryDetail();
	System.out.println(cdetail);
	
}
}
