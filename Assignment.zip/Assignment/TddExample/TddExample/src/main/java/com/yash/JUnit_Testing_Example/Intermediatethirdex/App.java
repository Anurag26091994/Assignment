package com.yash.JUnit_Testing_Example.Intermediatethirdex;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
