package com.yash.JUnit_Testing_Example.stringassigmentone;

public class DocumenttestMain {
	public static void main(String[] args) {
		documentmain dc=new documentmain();
		
		System.out.println(dc.showDocumentInformation());
	}

}
