package com.yash.JUnit_Testing_Example.stringassignmenttwo;

public class MemberInfoMain {
	public static void main(String[] args) {
		MemberInfo mi=new MemberInfo();
		
		String minfo=mi.showMemberDetail();
		System.out.println(minfo);
	}

}
